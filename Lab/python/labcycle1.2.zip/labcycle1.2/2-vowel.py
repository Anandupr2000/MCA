vowel =["a","e","i","o","u","A","E","I","O","U"]
inp = input("Enter a character : ")
if inp in vowel:
	print(f"{inp} is vowel.") 
else:
	print(f"{inp} is not vowel.") 
