num = int(input("Enter a number : "))
if num ==1:
	print("Number is neither even nor odd")
elif num%2==0:
	print("Number is even")
else:
	print("Number is odd")
