r = int(input("Enter radius : "))
area = r*r*3.21
print(f"Area of circle with {r} radius = {area}")
