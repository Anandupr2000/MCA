firstName = input("Enter first name : ")
lastName = input("Enter second name : ")
print(f"Greetings!!! {firstName} {lastName}")
