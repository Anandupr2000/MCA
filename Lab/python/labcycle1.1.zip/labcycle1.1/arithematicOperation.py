num1 = int(input("Enter first number : "))
num2 = int(input("Enter second number : "))
sum1 = num1+num2
sub = num1-num2
mul = num1*num2
div = num1/num2
intergerDivision = num1//num2
rem = num1%num2
print(f"number1 = {num1}, number2 = {num2}")
print(f"{num1} + {num2} = {sum1}") 
print(f"{num1} - {num2} = {sub}") 
print(f"{num1} * {num2} = {mul}") 
print(f"{num1} / {num2} = {div}") 
print(f"{num1} // {num2} = {intergerDivision}") 
print(f"{num1} % {num2} = {rem}") 
